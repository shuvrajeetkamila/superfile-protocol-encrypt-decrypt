Nested text inside the SUPERFILE demo ZIP.
